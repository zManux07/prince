// Chapter data
const chapterData = {
    intro: {
        title: 'The Aviator and His Childhood',
        subtitle: 'Chapters 1 to 2',
        icon: '✈️',
        content: [
            'The narrator recalls his childhood: at the age of 6 he saw a picture of a snake swallowing an elephant and drew it. But adults didn’t understand his drawing: they all saw a simple hat.',
            'Disappointed by adults’ lack of imagination, he stopped drawing and chose to become an aviator.',
            'Decades later, his plane breaks down and crashes in the Sahara desert. There, in the middle of nowhere, a strange-looking boy with golden hair says: "Please, draw me a sheep!"',
            'This moment marks the beginning of a deep relationship between the aviator and the Little Prince, a boy who seems to come from another world.'
        ],
        lesson: 'Adults have lost the ability to see with imagination and understand what’s essential.'
    },
    planet: {
        title: 'The Sheep and the Little Prince’s Planet',
        subtitle: 'Chapters 3 to 4',
        icon: '🌍',
        content: [
            'The Little Prince rejects the aviator’s first drawings until he draws a box and says the sheep is inside. The boy is happy: he uses his imagination freely, something adults have lost.',
            'He tells that he comes from a planet so small he can see multiple sunsets a day just by moving his chair. Later, he reveals the name of the planet: Asteroid B-612.',
            'Only a Turkish astronomer recorded it, but no one took him seriously because of his clothing.',
            'The criticism here is clear: adults focus on appearance, not substance.'
        ],
        lesson: 'Imagination is more powerful than apparent reality, and prejudice keeps us from seeing the truth.'
    },
    rose: {
        title: 'His Life on the Asteroid and the Rose',
        subtitle: 'Chapters 5 to 8',
        icon: '🌹',
        content: [
            'The Little Prince takes care of his planet: he cleans his volcanoes (active and inactive) and pulls out baobabs before they grow, because they would destroy his little world. This task represents discipline and personal responsibility.',
            'One day, a different flower appears: a delicate, beautiful, yet proud rose. She asks for attention, contradicts herself, and although she clearly loves the Prince, she doesn’t know how to express it.',
            'The Little Prince, confused, feels hurt by her behavior.',
            'So, he decides to leave in order to better understand love, life, and adults. This part symbolizes how young people sometimes run from what they don’t understand (even love) in search of answers.'
        ],
        lesson: 'Love requires patience, understanding, and responsibility. Sometimes we run from what we love most because we don’t understand it.'
    },
    asteroids: {
        title: 'Journey to Six Asteroids',
        subtitle: 'Chapters 9 to 15',
        icon: '👥',
        content: [
            'During his journey, the Little Prince meets six characters, each representing an adult’s flaw.',
            'The King thinks he rules the universe and gives orders that would happen anyway. He doesn’t understand freedom or humility.',
            'The Vain Man only listens to praise and lives to be admired, even if he’s alone.',
            'The Drunkard drinks to forget the shame of drinking, representing vicious cycles and escapism.',
            'The Businessman counts and “owns” stars, confusing value with quantity.',
            'The Lamplighter lights and extinguishes a lamp non-stop. He’s the only one who doesn’t live for himself, and the Little Prince respects him.',
            'The Geographer is wise but never explores. He advises visiting Earth.'
        ],
        lesson: 'Each adult represents a way of losing the meaning of life: power, vanity, escapism, greed, blind obedience, and knowledge without experience.'
    },
    earth: {
        title: 'The Little Prince Arrives on Earth',
        subtitle: 'Chapters 16 to 20',
        icon: '🌎',
        content: [
            'Earth surprises him with its vastness and the number of strange adults. He feels lonely until he finds a garden full of roses just like his.',
            'He realizes his flower is not physically unique, which makes him cry.',
            'This is a key moment: the illusion that something special is visible with the eyes is shattered.',
            'His sadness gives way to an important lesson about the true value of things.'
        ],
        lesson: 'What makes something special is not its external appearance, but the relationship and care we give it.'
    },
    fox: {
        title: 'The Fox and the Bond',
        subtitle: 'Chapters 21 to 25',
        icon: '🦊',
        content: [
            'The Fox asks to be tamed. He teaches the Little Prince that when someone tames you (loves you and you love them), you become unique to each other.',
            'Then the Prince understands that his rose is unique because it is his — the one he watered, protected, and cared for.',
            '"It’s the time you spent on your rose that makes it important."',
            'In the desert, the Little Prince meets a mysterious snake, which represents death or a spiritual passage.',
            'He also finds a well of water with the aviator. The water represents the value of what is essential.',
            'When the plane is repaired, the Prince says goodbye to the aviator. The snake bites him, and the next day, his body is gone.',
            'The aviator never forgets the Little Prince and looks at the stars remembering someone out there is caring for a rose.'
        ],
        lesson: 'True love is built with time, dedication, and care. The bonds we form are what give meaning to our lives.'
    }
};

// Memorable quotes
const quotes = [
    {
        text: "What is essential is invisible to the eye.",
        author: "The Fox",
        context: "The most important lesson of the book"
    },
    {
        text: "It’s the time you spent on your rose that makes it important.",
        author: "The Fox",
        context: "About the value of love and dedication"
    },
    {
        text: "All grown-ups were once children — but only few of them remember it.",
        author: "The Aviator",
        context: "About keeping the childlike spirit alive"
    }
];

// Global variables
let currentQuote = 0;
let quoteInterval;

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeStars();
    initializeDarkMode();
    initializeChapterNavigation();
    initializeQuotes();
});

// Create floating stars
function initializeStars() {
    const starsContainer = document.getElementById('starsContainer');
    const numberOfStars = 50;
    
    for (let i = 0; i < numberOfStars; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        star.innerHTML = '⭐';
        star.style.left = Math.random() * 100 + '%';
        star.style.top = Math.random() * 100 + '%';
        star.style.fontSize = (Math.random() * 16 + 8) + 'px';
        star.style.animationDelay = Math.random() * 3 + 's';
        star.style.animationDuration = (Math.random() * 2 + 2) + 's';
        starsContainer.appendChild(star);
    }
}

// Dark mode
function initializeDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        body.classList.add('dark-mode');
    }
    
    darkModeToggle.addEventListener('click', function() {
        body.classList.toggle('dark-mode');
        const isDark = body.classList.contains('dark-mode');
        localStorage.setItem('darkMode', isDark);
    });
}

// Chapter navigation
function initializeChapterNavigation() {
    const chapterButtons = document.querySelectorAll('.chapter-btn');
    
    chapterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const chapterId = this.getAttribute('data-chapter');
            chapterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            updateChapterContent(chapterId);
        });
    });
}

// Update chapter content
function updateChapterContent(chapterId) {
    const chapter = chapterData[chapterId];
    if (!chapter) return;
    
    const chapterIcon = document.getElementById('chapterIcon');
    const chapterTitle = document.getElementById('chapterTitle');
    const chapterSubtitle = document.getElementById('chapterSubtitle');
    const chapterText = document.getElementById('chapterText');
    const chapterLesson = document.getElementById('chapterLesson');
    
    const chapterCard = document.getElementById('chapterCard');
    chapterCard.style.opacity = '0';
    chapterCard.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        chapterIcon.textContent = chapter.icon;
        chapterTitle.textContent = chapter.title;
        chapterSubtitle.textContent = chapter.subtitle;
        
        chapterText.innerHTML = '';
        chapter.content.forEach(paragraph => {
            const p = document.createElement('p');
            p.textContent = paragraph;
            chapterText.appendChild(p);
        });
        
        chapterLesson.querySelector('p').textContent = chapter.lesson;
        
        chapterCard.style.opacity = '1';
        chapterCard.style.transform = 'translateY(0)';
    }, 300);
}

// Quote system
function initializeQuotes() {
    const quoteContainer = document.querySelector('.quote-container');
    quoteContainer.innerHTML = '';
    
    quotes.forEach((quote, index) => {
        const quoteCard = document.createElement('div');
        quoteCard.className = `quote-card ${index === 0 ? 'active' : ''}`;
        quoteCard.setAttribute('data-quote', index);
        
        quoteCard.innerHTML = `
            <div class="quote-icon">💬</div>
            <blockquote>
                <p>"${quote.text}"</p>
                <footer>
                    <cite>— ${quote.author}</cite>
                    <small>${quote.context}</small>
                </footer>
            </blockquote>
        `;
        quoteContainer.appendChild(quoteCard);
    });

    const quoteIndicators = document.querySelector('.quote-indicators');
    quoteIndicators.innerHTML = '';
    
    quotes.forEach((_, index) => {
        const dot = document.createElement('span');
        dot.className = `quote-dot ${index === 0 ? 'active' : ''}`;
        dot.setAttribute('data-quote', index);
        dot.addEventListener('click', () => showQuote(index));
        quoteIndicators.appendChild(dot);
    });

    document.getElementById('prevQuote').addEventListener('click', () => {
        currentQuote = (currentQuote - 1 + quotes.length) % quotes.length;
        showQuote(currentQuote);
    });

    document.getElementById('nextQuote').addEventListener('click', () => {
        currentQuote = (currentQuote + 1) % quotes.length;
        showQuote(currentQuote);
    });

    startQuoteRotation();
}

// Show specific quote
function showQuote(index) {
    const quoteCards = document.querySelectorAll('.quote-card');
    const quoteDots = document.querySelectorAll('.quote-dot');
    
    quoteCards.forEach(card => card.classList.remove('active'));
    quoteDots.forEach(dot => dot.classList.remove('active'));
    
    quoteCards[index].classList.add('active');
    quoteDots[index].classList.add('active');
    
    currentQuote = index;
}

// Auto-rotate quotes
function startQuoteRotation() {
    quoteInterval = setInterval(() => {
        currentQuote = (currentQuote + 1) % quotes.length;
        showQuote(currentQuote);
    }, 5000);
}

function stopQuoteRotation() {
    if (quoteInterval) {
        clearInterval(quoteInterval);
    }
}

function restartQuoteRotation() {
    stopQuoteRotation();
    setTimeout(startQuoteRotation, 10000);
}

document.addEventListener('DOMContentLoaded', function() {
    const quoteNavButtons = document.querySelectorAll('.quote-nav-btn');
    const quoteDots = document.querySelectorAll('.quote-dot');
    
    quoteNavButtons.forEach(btn => {
        btn.addEventListener('click', restartQuoteRotation);
    });
    
    quoteDots.forEach(dot => {
        dot.addEventListener('click', restartQuoteRotation);
    });
});

// Smooth scrolling for navigation
document.addEventListener('DOMContentLoaded', function() {
    const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        scrollIndicator.addEventListener('click', function() {
            document.querySelector('.chapter-navigation').scrollIntoView({
                behavior: 'smooth'
            });
        });
    }
});

// Scroll animations
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    const animatedElements = document.querySelectorAll('.character-card, .chapter-card');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

// === Quiz Game ===
const quizQuestions = [
    {
        question: "Who asks the aviator to draw a sheep?",
        options: ["The Fox", "The Rose", "The Little Prince", "The King"],
        answer: "The Little Prince"
    },
    {
        question: "What planet does the prince visit first?",
        options: ["Earth", "His own asteroid", "The King's planet", "The Geographer's planet"],
        answer: "The King's planet"
    },
    {
        question: "What does the fox teach the prince?",
        options: [
            "How to fly",
            "How to count stars",
            "The value of love and taming",
            "To become a king"
        ],
        answer: "The value of love and taming"
    }
];

function startQuiz() {
    const container = document.getElementById("quizContainer");
    container.innerHTML = "";
    quizQuestions.forEach((q, index) => {
        const qDiv = document.createElement("div");
        qDiv.classList.add("quiz-question");
        qDiv.innerHTML = `<h4>${index + 1}. ${q.question}</h4>`;
        q.options.forEach(opt => {
            qDiv.innerHTML += `
                <label><input type="radio" name="q${index}" value="${opt}"> ${opt}</label><br>`;
        });
        container.appendChild(qDiv);
    });
    container.innerHTML += `<button onclick="submitQuiz()">Submit Answers</button>`;
    container.style.display = "block";
}

function submitQuiz() {
    let score = 0;
    quizQuestions.forEach((q, index) => {
        const selected = document.querySelector(`input[name="q${index}"]:checked`);
        if (selected && selected.value === q.answer) score++;
    });
    alert(`You got ${score} out of ${quizQuestions.length} right!`);
}

// === Match Game ===
const matches = {
    "The King": "Loves to command, but doesn't understand logic.",
    "The Vain Man": "Wants praise and admiration.",
    "The Drunkard": "Drinks to forget his shame.",
    "The Lamplighter": "Blindly follows orders.",
};

function startMatching() {
    const container = document.getElementById("matchGameContainer");
    container.innerHTML = "";

    const characters = Object.keys(matches).sort(() => Math.random() - 0.5);
    const lessons = Object.values(matches).sort(() => Math.random() - 0.5);

    characters.forEach(c => {
        const select = document.createElement("select");
        select.dataset.character = c;
        select.innerHTML = `<option value="">Match lesson to: ${c}</option>`;
        lessons.forEach(l => {
            select.innerHTML += `<option value="${l}">${l}</option>`;
        });
        container.appendChild(select);
    });

    container.innerHTML += `<br><button onclick="submitMatch()">Submit Matches</button>`;
    container.style.display = "block";
}

function submitMatch() {
    let correct = 0;
    document.querySelectorAll("#matchGameContainer select").forEach(select => {
        const character = select.dataset.character;
        const selectedLesson = select.value;
        if (matches[character] === selectedLesson) correct++;
    });
    alert(`You matched ${correct} out of ${Object.keys(matches).length} correctly!`);
}

}

document.addEventListener('DOMContentLoaded', initializeScrollAnimations);
